#!/bin/bash
# Запуск русификатора Fusion 360 для macOS

echo "Запуск русификатора Fusion 360..."

# Проверяем наличие Python 3
if ! command -v python3 &> /dev/null; then
    echo "Ошибка: Python 3 не найден."
    echo "Установите Python 3: https://www.python.org/downloads/"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "$SCRIPT_DIR/rusificator_mac.py"
