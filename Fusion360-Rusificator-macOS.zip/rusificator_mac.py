#!/usr/bin/env python3
"""
Русификатор Autodesk Fusion 360 для macOS
Версия: v1.0.3 (Spotlight Search Fix)
"""

import os
import sys
import subprocess
import shutil
import zipfile
import urllib.request
import threading
import datetime
import tkinter as tk
from tkinter import messagebox, filedialog
from pathlib import Path

# Дата окончания действия программы (Год, Месяц, День)
# Сейчас установлено на 9 мая 2026 (через неделю от 2 мая)
EXPIRATION_DATE = datetime.date(2026, 10, 9)

VERSION = "1.0.5"

GITHUB_FILES = {
    "version.txt": "https://raw.githubusercontent.com/RusFus/fusion360-russian-files/main/version.txt",
    "russian_ru.xml": "https://raw.githubusercontent.com/RusFus/fusion360-russian-files/main/russian_ru.xml",
    "ru-html.zip": "https://raw.githubusercontent.com/RusFus/fusion360-russian-files/main/ru-html.zip",
    "ru-RU.zip": "https://raw.githubusercontent.com/RusFus/fusion360-russian-files/main/ru-RU.zip",
}


class FusionRusificatorMac:
    def __init__(self, root):
        self.root = root
        self.root.title(f"Русификатор Fusion 360 (v{VERSION})")
        self.root.geometry("600x520")
        self.root.resizable(False, False)
        self.root.configure(bg="#f0f0f0") 

        print(f"Запуск русификатора версии {VERSION}")

        self.fusion_paths = []
        self.temp_dir = Path.home() / ".fusion360_rusificator_temp"
        self.temp_dir.mkdir(exist_ok=True)
        self.version_file = Path.home() / ".fusion360_rusificator_version"
        self.installed_version = self._load_version()
        self.latest_version = None

        self._build_ui()
        
        # Автопоиск (включает Spotlight)
        self._find_fusion_paths()
        
        self._update_version_label()
        # self._check_updates_async()  # отключено — только локальные файлы

    def _build_ui(self):
        main_frame = tk.Frame(self.root, bg="#f0f0f0")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        title_label = tk.Label(main_frame, text="FUSION 360\nРУСИФИКАТОР", 
                               bg="#f0f0f0", fg="#333333", 
                               font=("Helvetica", 20, "bold"))
        title_label.pack(pady=(10, 5))

        self.status_label = tk.Label(main_frame, text="Поиск Fusion...", 
                                     bg="#f0f0f0", fg="#666666", 
                                     font=("Helvetica", 11))
        self.status_label.pack(pady=5)

        self.version_label = tk.Label(main_frame, text="", 
                                      bg="#f0f0f0", fg="#888888", 
                                      font=("Helvetica", 10))
        self.version_label.pack(pady=2)

        self.fusion_version_label = tk.Label(main_frame, text="", 
                                             bg="#f0f0f0", fg="#0055cc", 
                                             font=("Helvetica", 11, "bold"))
        self.fusion_version_label.pack(pady=10)

        # Блок ручного ввода пути
        path_frame = tk.Frame(main_frame, bg="#f0f0f0")
        path_frame.pack(fill=tk.X, pady=10)

        tk.Label(path_frame, text="Путь к Fusion:", bg="#f0f0f0", font=("Helvetica", 9)).pack(anchor="w")
        
        self.path_entry = tk.Entry(path_frame, font=("Helvetica", 10))
        self.path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        self.path_entry.insert(0, "/Applications/Autodesk Fusion.app")

        self.apply_path_btn = tk.Button(path_frame, text="Применить", command=self._apply_manual_path, 
                                        bg="#4CAF50", fg="white", relief="flat", cursor="hand2", font=("Helvetica", 9, "bold"))
        self.apply_path_btn.pack(side=tk.RIGHT)

        # Кнопка поиска через Spotlight
        self.spotlight_btn = tk.Button(main_frame, text="🔍 Найти Fusion (Spotlight)", 
                                    command=self._search_spotlight, 
                                    font=("Helvetica", 11, "bold"), 
                                    bg="#007aff", fg="white", 
                                    relief="flat", padx=10, pady=8, cursor="hand2")
        self.spotlight_btn.pack(fill=tk.X, pady=10)

        btn_frame = tk.Frame(main_frame, bg="#f0f0f0")
        btn_frame.pack(fill=tk.X, pady=10)

        self.install_btn = tk.Button(btn_frame, text="Установить русификатор", 
                                     command=self._on_install, 
                                     font=("Helvetica", 12, "bold"), 
                                     bg="#007aff", fg="white", 
                                     activebackground="#0055cc", activeforeground="white",
                                     relief="flat", padx=10, pady=8, cursor="hand2")
        self.install_btn.pack(fill=tk.X, pady=5)

        self.remove_btn = tk.Button(btn_frame, text="Удалить русификатор", 
                                    command=self._on_remove, 
                                    font=("Helvetica", 12, "bold"), 
                                    bg="#d93025", fg="white", 
                                    activebackground="#b02015", activeforeground="white",
                                    relief="flat", padx=10, pady=8, cursor="hand2")
        self.remove_btn.pack(fill=tk.X, pady=5)

        # Кнопка поддержки проекта
        self.donate_btn = tk.Button(main_frame, text="💖 Поддержать проект", 
                                    command=self._show_donate, 
                                    font=("Helvetica", 11, "bold"), 
                                    bg="#ff4081", fg="white", 
                                    activebackground="#e91e63", activeforeground="white",
                                    relief="flat", padx=10, pady=6, cursor="hand2")
        self.donate_btn.pack(fill=tk.X, pady=10)

        self.progress_text = tk.Label(main_frame, text="", 
                                      bg="#f0f0f0", fg="#555555", 
                                      font=("Helvetica", 10))
        self.progress_text.pack(pady=10)

        link_label = tk.Label(main_frame, text="Репозиторий на GitHub", 
                              bg="#f0f0f0", fg="#0055cc", 
                              font=("Helvetica", 10, "underline"), cursor="hand2")
        link_label.pack(side=tk.BOTTOM)
        link_label.bind("<Button-1>", lambda e: self._open_url("https://github.com/RusFus/fusion360-russian-files"))

    def _search_spotlight(self):
        """Ищет приложение через системный поиск mdfind"""
        try:
            self._set_status("Поиск через Spotlight...", "#666666")
            self.root.update()
            
            # Ищем по имени
            result = subprocess.run(["mdfind", "kMDItemFSName == 'Autodesk Fusion.app'"], 
                                    capture_output=True, text=True)
            
            paths = result.stdout.strip().split('\n')
            
            if not paths or paths == ['']:
                # Пробуем без 360
                result = subprocess.run(["mdfind", "kMDItemFSName == 'Autodesk Fusion 360.app'"], 
                                        capture_output=True, text=True)
                paths = result.stdout.strip().split('\n')

            if not paths or paths == ['']:
                 # Пробуем просто Fusion
                result = subprocess.run(["mdfind", "kMDItemFSName == 'Fusion.app'"], 
                                        capture_output=True, text=True)
                paths = result.stdout.strip().split('\n')

            found_path = None
            for p in paths:
                if p and self._check_fusion_structure(Path(p)):
                    found_path = p
                    break
            
            if found_path:
                self.path_entry.delete(0, tk.END)
                self.path_entry.insert(0, found_path)
                self._apply_manual_path()
                self.spotlight_btn.configure(state="disabled", bg="#e0e0e0", text="✅ Найден через Spotlight")
            else:
                messagebox.showwarning("Не найдено", "Spotlight не нашел Fusion.\nПопробуйте ввести путь вручную.")
                self._set_status("Не найдено", "#cc0000")

        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка поиска: {e}")

    def _apply_manual_path(self):
        """Применяет путь из текстового поля"""
        path_str = self.path_entry.get().strip()
        if not path_str:
            messagebox.showwarning("Пусто", "Введите путь к папке приложения.")
            return
        
        path = Path(path_str)
        
        if path.name == "Contents":
            path = path.parent
        
        if self._check_fusion_structure(path):
            self.fusion_paths = [path]
            self.fusion_version_label.configure(text=f"Выбран: {self._get_fusion_version(path)}")
            self._set_status("Fusion 360 выбран", "#008800")
            self.apply_path_btn.configure(state="disabled")
            self.path_entry.configure(state="disabled", disabledforeground="#008800")
            messagebox.showinfo("Успех", "Fusion 360 найден! Можно устанавливать.")
        else:
            messagebox.showerror("Ошибка", "Неверный путь.\nУбедитесь, что путь ведет к папке Autodesk Fusion.app")

    def _load_version(self):
        try:
            if self.version_file.exists():
                return self.version_file.read_text().strip()
        except Exception:
            pass
        return VERSION

    def _save_version(self, version):
        try:
            self.version_file.write_text(version)
            self.installed_version = version
        except Exception:
            pass

    def _update_version_label(self):
        self.version_label.configure(text=f"Русификатор v{self.installed_version}")

    def _set_status(self, text, color="#666666"):
        self.status_label.configure(text=text, fg=color)

    def _set_progress(self, text):
        self.progress_text.configure(text=text)

    def _check_fusion_structure(self, app_path):
        """Проверяет, есть ли внутри .app пакета нужные папки Fusion"""
        libs = app_path / "Contents/Libraries"
        target = libs / "Applications/CAM360"
        return target.exists()

    def _find_fusion_paths(self):
        self.fusion_paths = []
        
        # 1. Попытка найти стандартные пути
        candidates = [
            Path("/Applications/Autodesk Fusion.app"),
            Path("/Applications/Autodesk Fusion 360.app"),
            Path("/Applications/Fusion 360.app"),
        ]
        
        for p in candidates:
            if p.exists() and self._check_fusion_structure(p):
                self.fusion_paths.append(p)
                self.path_entry.delete(0, tk.END)
                self.path_entry.insert(0, str(p))
                break

        # 2. Если не нашли - пробуем mdfind (Spotlight) автоматически
        if not self.fusion_paths:
            try:
                result = subprocess.run(["mdfind", "kMDItemFSName == 'Autodesk Fusion.app'"], 
                                        capture_output=True, text=True)
                paths = [p for p in result.stdout.strip().split('\n') if p]
                
                for p in paths:
                    if self._check_fusion_structure(Path(p)):
                        self.fusion_paths.append(Path(p))
                        self.path_entry.delete(0, tk.END)
                        self.path_entry.insert(0, p)
                        break
            except Exception:
                pass

        if self.fusion_paths:
            ver = self._get_fusion_version(self.fusion_paths[0])
            self.fusion_version_label.configure(text=f"Найден: {ver}")
            self._set_status("Fusion 360 обнаружен", "#008800")
            self.apply_path_btn.configure(state="disabled")
            self.path_entry.configure(state="disabled")
            self.spotlight_btn.configure(state="disabled", bg="#e0e0e0", text="✅ Найден")
        else:
            self.fusion_version_label.configure(text="Не выбран")
            self._set_status("Нажмите 'Найти Fusion'", "#cc0000")

    def _get_fusion_version(self, fusion_path):
        try:
            libs = fusion_path / "Contents/Libraries"
            ver_file = libs / "fusion_version.txt"
            if ver_file.exists():
                text = ver_file.read_text().strip()
                if "." in text:
                    parts = text.split(".")
                    if len(parts) >= 3:
                        return f"Fusion v{parts[0]}.{parts[1]}.{parts[2]}"
                return f"Fusion 360 v{text}"
        except Exception:
            pass
        return "Fusion 360"

    def _is_fusion_running(self):
        try:
            result = subprocess.run(["pgrep", "-fl", "Fusion"], capture_output=True, text=True)
            return len(result.stdout.strip()) > 0
        except Exception:
            return False

    def _kill_fusion(self):
        try:
            subprocess.run(["pkill", "-f", "Fusion"], capture_output=True)
            return True
        except Exception:
            return False

    def _check_updates_async(self):
        threading.Thread(target=self._check_updates, daemon=True).start()

    def _check_updates(self):
        try:
            self.root.after(0, lambda: self._set_status("Проверка обновлений...", "#666666"))
            req = urllib.request.Request(GITHUB_FILES["version.txt"], headers={"User-Agent": "Fusion360Rusificator"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                self.latest_version = resp.read().decode().strip()

            if self.latest_version and self.latest_version != self.installed_version:
                self.root.after(0, lambda: self._set_status(f"Доступна новая версия: {self.latest_version}", "#cc6600"))
            else:
                self.root.after(0, lambda: self._set_status("Версия актуальна", "#008800"))
        except Exception:
            self.root.after(0, lambda: self._set_status("Нет интернета", "#cc0000"))

    def _on_install(self):
        if not self.fusion_paths:
            messagebox.showwarning("Внимание", "Сначала найдите Fusion (кнопка 'Найти Fusion').")
            return

        # Проверяем интернет и локальные файлы
        has_internet = False
        has_local_files = self._check_local_files()
        
        if not self.latest_version:
            self._check_updates()
            import time
            time.sleep(2) 
            if self.latest_version:
                has_internet = True
        
        # Если нет ни интернета, ни локальных файлов
        if not has_internet and not has_local_files:
            messagebox.showerror("Ошибка", 
                                 "Нет подключения к интернету и отсутствуют локальные файлы.\n\n"
                                 "Варианты решения:\n"
                                 "1. Подключитесь к интернету и попробуйте снова.\n"
                                 "2. Положите файлы (russian_ru.xml, ru-html.zip, ru-RU.zip) \n"
                                 "   в одну папку со скриптом и запустите его снова.")
            return

        if self._is_fusion_running():
            if not messagebox.askyesno("Fusion 360 запущен", "Fusion 360 запущен. Закрыть его?"):
                return
            self._kill_fusion()
            import time
            time.sleep(1)

        threading.Thread(target=self._install, daemon=True).start()

    def _install(self):
        try:
            self.root.after(0, lambda: self._set_status("Установка...", "#666666"))
            self.root.after(0, lambda: self._set_progress("Подготовка..."))

            files_loaded = False
            
            # 1. Пробуем скачать из интернета
            self.root.after(0, lambda: self._set_progress("Загрузка файлов..."))
            if self._download_files():
                files_loaded = True
            
            # 2. Если скачивание не удалось — берём локальные файлы
            if not files_loaded:
                self.root.after(0, lambda: self._set_progress("Используются локальные файлы..."))
                if not self._copy_local_files():
                    self.root.after(0, lambda: messagebox.showerror("Ошибка", "Не удалось загрузить или найти файлы русификации."))
                    self.root.after(0, lambda: self._set_status("Ошибка: файлы не найдены", "#cc0000"))
                    return

            self.root.after(0, lambda: self._set_progress("Распаковка..."))
            if not self._extract_files():
                self.root.after(0, lambda: messagebox.showerror("Ошибка", "Ошибка распаковки."))
                self.root.after(0, lambda: self._set_status("Ошибка распаковки", "#cc0000"))
                return

            self.root.after(0, lambda: self._set_progress("Очистка старых файлов..."))
            self._cleanup_old()

            self.root.after(0, lambda: self._set_progress("Установка..."))
            success = self._install_files()
            if not success:
                self.root.after(0, lambda: messagebox.showerror("Ошибка", "Не удалось установить."))
                self.root.after(0, lambda: self._set_status("Ошибка установки", "#cc0000"))
                return

            # Если устанавливали локально, пишем версию "локальная"
            ver_to_save = self.latest_version if self.latest_version else "локальная"
            self._save_version(ver_to_save)
            self.root.after(0, self._update_version_label)
            self.root.after(0, lambda: self._set_progress("Готово!"))
            self.root.after(0, lambda: self._set_status("Установлено!", "#008800"))
            
            def ask_launch():
                if messagebox.askyesno("Успех", "Русификатор установлен!\nЗапустить Fusion 360?"):
                    self._launch_fusion()
            self.root.after(0, ask_launch)

        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
            self.root.after(0, lambda: self._set_status("Ошибка", "#cc0000"))
        finally:
            self._cleanup_temp()
            self.root.after(0, lambda: self._set_progress(""))

    def _download_files(self):
        # Скачивание с GitHub отключено — используем только локальные файлы
        return False

    def _check_local_files(self):
        """Проверяет наличие локальных файлов русификации рядом со скриптом"""
        script_dir = Path(__file__).parent
        required = ["russian_ru.xml", "ru-html.zip", "ru-RU.zip"]
        return all((script_dir / f).exists() for f in required)

    def _copy_local_files(self):
        """Копирует локальные файлы из папки со скриптом во временную директорию"""
        try:
            script_dir = Path(__file__).parent
            for name in ["russian_ru.xml", "ru-html.zip", "ru-RU.zip"]:
                src = script_dir / name
                if src.exists():
                    shutil.copy2(src, self.temp_dir / name)
                else:
                    return False
            return True
        except Exception:
            return False

    def _extract_files(self):
        try:
            for zip_name, extract_name in [("ru-html.zip", "ru-html"), ("ru-RU.zip", "ru-RU")]:
                zip_path = self.temp_dir / zip_name
                if not zip_path.exists():
                    return False
                extract_path = self.temp_dir / extract_name
                if extract_path.exists():
                    shutil.rmtree(extract_path)
                with zipfile.ZipFile(zip_path, "r") as zf:
                    zf.extractall(extract_path)
                if not extract_path.exists() or not any(extract_path.iterdir()):
                    return False
            return True
        except Exception:
            return False

    def _cleanup_old(self):
        for fusion_path in self.fusion_paths:
            libs = fusion_path / "Contents/Libraries"
            try:
                targets = [
                    libs / "Applications/CAM360/Data/Translations/russian_ru.xml",
                    libs / "Applications/CAM360/NeuCAM/UI/NeuCAMUI/Resources/Help/ru-html",
                    libs / "Neutron/StringTable/ru-RU",
                ]
                for target in targets:
                    if target.exists():
                        if target.is_dir():
                            shutil.rmtree(target)
                        else:
                            target.unlink()
            except Exception:
                pass

    def _install_files(self):
        success = False
        for fusion_path in self.fusion_paths:
            libs = fusion_path / "Contents/Libraries"
            try:
                trans_dir = libs / "Applications/CAM360/Data/Translations"
                src_xml = self.temp_dir / "russian_ru.xml"
                if trans_dir.exists() and src_xml.exists():
                    shutil.copy2(src_xml, trans_dir / "russian_ru.xml")
                    success = True

                help_dir = libs / "Applications/CAM360/NeuCAM/UI/NeuCAMUI/Resources/Help"
                src_html = self.temp_dir / "ru-html"
                if help_dir.exists() and src_html.exists():
                    dest = help_dir / "ru-html"
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(src_html, dest)
                    success = True

                strings_dir = libs / "Neutron/StringTable"
                src_ru = self.temp_dir / "ru-RU"
                if strings_dir.exists() and src_ru.exists():
                    dest = strings_dir / "ru-RU"
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(src_ru, dest)
                    success = True
            except Exception:
                pass
        return success

    def _on_remove(self):
        if not self.fusion_paths:
            messagebox.showwarning("Внимание", "Сначала найдите Fusion.")
            return

        if self._is_fusion_running():
            if not messagebox.askyesno("Fusion 360 запущен", "Закрыть Fusion для удаления?"):
                return
            self._kill_fusion()
            import time
            time.sleep(1)

        if not messagebox.askyesno("Подтверждение", "Удалить русификацию?"):
            return

        threading.Thread(target=self._remove, daemon=True).start()

    def _remove(self):
        try:
            self.root.after(0, lambda: self._set_status("Удаление...", "#666666"))
            self.root.after(0, lambda: self._set_progress("Удаление..."))
            self._cleanup_old()
            self._save_version("не установлено")
            self.root.after(0, self._update_version_label)
            self.root.after(0, lambda: self._set_progress("Готово!"))
            self.root.after(0, lambda: self._set_status("Удалено", "#cc6600"))
            self.root.after(0, lambda: messagebox.showinfo("Успех", "Русификация удалена!"))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
            self.root.after(0, lambda: self._set_status("Ошибка", "#cc0000"))
        finally:
            self.root.after(0, lambda: self._set_progress(""))

    def _cleanup_temp(self):
        try:
            if self.temp_dir.exists():
                shutil.rmtree(self.temp_dir)
            self.temp_dir.mkdir(exist_ok=True)
        except Exception:
            pass

    def _launch_fusion(self):
        try:
            for fusion_path in self.fusion_paths:
                if fusion_path.name.endswith(".app"):
                    subprocess.run(["open", "-a", str(fusion_path)])
                    break
        except Exception as e:
            print(f"Launch error: {e}")

    def _show_donate(self):
        """Открывает окно с QR-кодом для поддержки проекта"""
        win = tk.Toplevel(self.root)
        win.title("Поддержать проект")
        win.geometry("350x420")
        win.resizable(False, False)
        win.configure(bg="#ffffff")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="💖 СПАСИБО!", font=("Helvetica", 18, "bold"), 
                 bg="#ffffff", fg="#ff4081").pack(pady=(20, 5))

        tk.Label(win, text="Ваша поддержка помогает развивать проект!", 
                 font=("Helvetica", 10), bg="#ffffff", fg="#666666").pack(pady=(0, 15))

        # QR-код из файла
        script_dir = Path(__file__).parent
        qr_path = script_dir / "donate_qr.png"
        
        if qr_path.exists():
            try:
                qr_image = tk.PhotoImage(file=str(qr_path))
                qr_label = tk.Label(win, image=qr_image, bg="#ffffff")
                qr_label.image = qr_image  # Сохраняем ссылку
                qr_label.pack(pady=10)
            except Exception:
                pass

        # Реквизиты
        info_frame = tk.Frame(win, bg="#f5f5f5", padx=15, pady=10)
        info_frame.pack(fill=tk.X, padx=20, pady=10)
        
        tk.Label(info_frame, text="Тинькофф / Т-Банк:", font=("Helvetica", 9, "bold"), 
                 bg="#f5f5f5", fg="#333333").pack()
        tk.Label(info_frame, text="4276 3801 4813 3494", font=("Helvetica", 11), 
                 bg="#f5f5f5", fg="#333333").pack(pady=(2, 5))
        
        tk.Label(info_frame, text="Т-Банк: 2200 7019 3062 0445", font=("Helvetica", 11), 
                 bg="#f5f5f5", fg="#333333").pack(pady=(0, 5))

        # Кнопка для перехода на страницу оплаты
        donate_link_btn = tk.Button(win, text="💳 Перейти к оплате", 
                                    command=lambda: self._open_url("https://pay.cloudtips.ru/p/55f51d8a"),
                                    font=("Helvetica", 12, "bold"), 
                                    bg="#ffcc00", fg="#333333", 
                                    activebackground="#e6b800", activeforeground="#333333",
                                    relief="flat", padx=15, pady=8, cursor="hand2")
        donate_link_btn.pack(pady=15)

        tk.Button(win, text="Закрыть", command=win.destroy, 
                  font=("Helvetica", 9), bg="#e0e0e0", fg="#333333", 
                  relief="flat", padx=20, pady=4, cursor="hand2").pack(pady=(0, 10))

    @staticmethod
    def _open_url(url):
        subprocess.run(["open", url])


def main():
    # Проверка срока действия программы
    if datetime.date.today() > EXPIRATION_DATE:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Срок действия истек", 
                             "Данная версия программы перестала работать.\n"
                             "Скачайте новую версию с GitHub.")
        root.destroy()
        sys.exit(1)

    root = tk.Tk()
    app = FusionRusificatorMac(root)
    root.mainloop()


if __name__ == "__main__":
    main()
